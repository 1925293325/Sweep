<?php
/**
 * Sweep 清理插件残留表
 * 
 * @package Sweep
 * @author Lin
 * @version 1.0.0
 * @link https://linyu.live
 */

class Sweep_Plugin implements Typecho_Plugin_Interface
{
    public static function activate()
    {
        Helper::addPanel(1, 'Sweep/panel.php', '数据库清理', '清理插件残留表', 'administrator');
        return '插件已启用，请访问"控制台 -> 数据库清理"使用';
    }

    public static function deactivate()
    {
        Helper::removePanel(1, 'Sweep/panel.php');
        return '插件已禁用';
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 无需配置
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
        // 无需个人配置
    }

    /**
     * 智能识别插件归属
     * 结合表名模式与字段特征匹配
     */
    public static function detectPlugin($tableName, $db)
    {
        $prefix = $db->getPrefix();
        $shortName = str_replace($prefix, '', $tableName);
        $shortNameLower = strtolower($shortName);
        
        // 获取表结构
        $columns = array();
        try {
            $cols = $db->fetchAll("SHOW COLUMNS FROM `{$tableName}`");
            foreach ($cols as $col) {
                $columns[] = strtolower($col['Field']);
            }
        } catch (Exception $e) {
            // 读取失败则仅使用表名匹配
        }
        
        // 插件指纹库：表名关键词 + 特征字段 + 权重
        $fingerprints = array(
            'links' => array(
                'keywords' => array('links', 'link', 'friendlink', 'youlian', 'blogroll'),
                'fields' => array('url', 'link', 'href', 'target', 'description', 'sort', 'image'),
                'weight' => 0.9,
                'name' => '友链管理'
            ),
            'baidu_push' => array(
                'keywords' => array('baidu', 'push', 'sitemap', 'seo_push', 'baidupush'),
                'fields' => array('push_id', 'push_status', 'push_time', 'api_key', 'remain', 'success'),
                'weight' => 0.85,
                'name' => '百度推送'
            ),
            'cache' => array(
                'keywords' => array('cache', 'redis', 'memcached', 'trcache', 'caches'),
                'fields' => array('cache_key', 'cache_value', 'expire', 'ttl', 'expire_time', 'cachedata'),
                'weight' => 0.85,
                'name' => '缓存系统'
            ),
            'ai_comment' => array(
                'keywords' => array('ai', 'commentai', 'chat', 'gpt', 'openai', 'gemini'),
                'fields' => array('ai_reply', 'gpt_response', 'token_usage', 'model', 'prompt', 'temperature'),
                'weight' => 0.9,
                'name' => 'AI评论'
            ),
            'album' => array(
                'keywords' => array('album', 'photo', 'gallery', 'image', 'pic', 'imgs'),
                'fields' => array('img_url', 'thumb', 'photo_path', 'exif', 'album_id', 'cdn_url'),
                'weight' => 0.85,
                'name' => '相册管理'
            ),
            'statistics' => array(
                'keywords' => array('stat', 'stats', 'analytics', 'visit', 'view', 'counter', 'visitor'),
                'fields' => array('ip', 'ua', 'referer', 'page_views', 'visit_time', 'visitor_id', 'country'),
                'weight' => 0.8,
                'name' => '统计系统'
            ),
            'user_ext' => array(
                'keywords' => array('user_ext', 'vip', 'member', 'profile', 'avatar', 'credits'),
                'fields' => array('user_id', 'credits', 'level', 'vip_expire', 'phone', 'qq', 'wechat'),
                'weight' => 0.75,
                'name' => '用户扩展'
            ),
            'payment' => array(
                'keywords' => array('pay', 'order', 'payment', 'trade', 'wxpay', 'alipay', 'orderinfo'),
                'fields' => array('order_id', 'amount', 'status', 'pay_time', 'transaction_id', 'buyer'),
                'weight' => 0.9,
                'name' => '支付系统'
            ),
            'backup' => array(
                'keywords' => array('backup', 'export', 'snapshot', 'dump'),
                'fields' => array('file_path', 'file_size', 'backup_time', 'tables', 'filename'),
                'weight' => 0.8,
                'name' => '备份系统'
            ),
            'log' => array(
                'keywords' => array('log', 'error_log', 'debug', 'record', 'logs'),
                'fields' => array('level', 'message', 'context', 'created_at', 'logger', 'channel'),
                'weight' => 0.7,
                'name' => '日志系统'
            ),
            'shortlink' => array(
                'keywords' => array('short', 'shortlink', 'urlshort', 'tinyurl', 'go'),
                'fields' => array('short_code', 'long_url', 'clicks', 'expired_at'),
                'weight' => 0.85,
                'name' => '短链接'
            ),
            'contribute' => array(
                'keywords' => array('contribute', 'submit', 'contribution', 'tougao'),
                'fields' => array('author', 'content', 'status', 'submitted_at', 'reviewer'),
                'weight' => 0.8,
                'name' => '投稿系统'
            ),
            'attachment' => array(
                'keywords' => array('attachment', 'upload', 'file', 'oss', 'cos', 'qiniu'),
                'fields' => array('file_name', 'file_size', 'mime_type', 'storage', 'remote_url'),
                'weight' => 0.75,
                'name' => '附件管理'
            ),
            'seo' => array(
                'keywords' => array('seo', 'keyword', 'tag', 'meta', 'spider'),
                'fields' => array('keywords', 'description', 'spider_name', 'spider_time'),
                'weight' => 0.7,
                'name' => 'SEO工具'
            ),
            'notification' => array(
                'keywords' => array('notify', 'notice', 'msg', 'message', 'notification', 'webhook'),
                'fields' => array('recipient', 'content', 'is_read', 'sent_at', 'type'),
                'weight' => 0.75,
                'name' => '消息通知'
            )
        );
        
        $scores = array();
        
        foreach ($fingerprints as $key => $fp) {
            $score = 0;
            $nameMatched = false;
            $fieldMatched = false;
            
            // 表名匹配（60%权重）
            foreach ($fp['keywords'] as $keyword) {
                if (strpos($shortNameLower, $keyword) !== false) {
                    $score += $fp['weight'] * 0.6;
                    $nameMatched = true;
                    break;
                }
            }
            
            // 字段匹配（40%权重）
            if (!empty($columns)) {
                $matchCount = 0;
                foreach ($fp['fields'] as $fieldSig) {
                    foreach ($columns as $col) {
                        if (strpos($col, $fieldSig) !== false) {
                            $matchCount++;
                            break;
                        }
                    }
                }
                if ($matchCount > 0) {
                    // 匹配字段越多分数越高，但封顶
                    $fieldScore = min($matchCount * 0.15, $fp['weight'] * 0.4);
                    $score += $fieldScore;
                    $fieldMatched = $matchCount >= 2; // 至少匹配2个字段才算真的匹配
                }
            }
            
            if ($nameMatched || ($fieldMatched && $score > 0.3)) {
                $scores[$key] = array(
                    'score' => $score,
                    'name' => $fp['name'],
                    'matched' => array(
                        'name' => $nameMatched,
                        'field' => $fieldMatched
                    )
                );
            }
        }
        
        if (empty($scores)) {
            return array(
                'name' => '未知插件',
                'confidence' => 'low',
                'score' => 0
            );
        }
        
        // 排序取最高
        uasort($scores, function($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        
        $best = reset($scores);
        $score = $best['score'];
        
        // 置信度分级
        if ($score >= 0.7 && $best['matched']['name'] && $best['matched']['field']) {
            $confidence = 'high'; // 高置信：表名和字段都匹配
        } elseif ($score >= 0.5 || ($best['matched']['name'] && $score >= 0.4)) {
            $confidence = 'medium'; // 中置信：表名匹配或分数还行
        } else {
            $confidence = 'low'; // 低置信：猜测
        }
        
        return array(
            'name' => $best['name'],
            'confidence' => $confidence,
            'score' => round($score, 2)
        );
    }
}
?>
