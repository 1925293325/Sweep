<?php
/**
 * 数据库表清理插件
 * 扫描并删除已卸载插件遗留的数据表
 * 
 * @package TableCleaner
 * @Lin. https://linyu.live
 * @version 1.0.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class TableCleaner_Plugin implements Typecho_Plugin_Interface
{
    // Typecho 核心表（这些表不能删除）
    private static $coreTables = array(
        'contents', 'comments', 'metas', 'relationships', 
        'users', 'options', 'fields', 'searchcache'
    );

    public static function activate()
    {
        Helper::addPanel(3, 'TableCleaner/panel.php', '数据库清理', '清理插件残留数据表', 'administrator');
        return _t('插件已激活，请在后台"扩展"菜单中使用');
    }

    public static function deactivate()
    {
        Helper::removePanel(3, 'TableCleaner/panel.php');
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 无需配置
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    /**
     * 获取所有非核心表
     */
    public static function getPluginTables()
    {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        $adapter = $db->getAdapterName();
        
        $tables = array();
        
        try {
            if (strpos($adapter, 'Mysql') !== false || strpos($adapter, 'PDO') !== false) {
                // MySQL
                $sql = "SHOW TABLES LIKE '{$prefix}%'";
                $result = $db->fetchAll($sql);
                
                foreach ($result as $row) {
                    $tableName = array_values($row)[0];
                    $shortName = str_replace($prefix, '', $tableName);
                    
                    // 跳过核心表
                    if (in_array($shortName, self::$coreTables)) {
                        continue;
                    }
                    
                    // 获取表信息
                    $count = $db->fetchObject("SELECT COUNT(*) as count FROM `{$tableName}`")->count;
                    $tables[] = array(
                        'full_name' => $tableName,
                        'short_name' => $shortName,
                        'count' => $count,
                        'size' => self::getTableSize($tableName)
                    );
                }
            } elseif (strpos($adapter, 'SQLite') !== false) {
                // SQLite
                $result = $db->fetchAll("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '{$prefix}%'");
                foreach ($result as $row) {
                    $tableName = $row['name'];
                    $shortName = str_replace($prefix, '', $tableName);
                    
                    if (in_array($shortName, self::$coreTables)) continue;
                    
                    $count = $db->fetchObject("SELECT COUNT(*) as count FROM `{$tableName}`")->count;
                    $tables[] = array(
                        'full_name' => $tableName,
                        'short_name' => $shortName,
                        'count' => $count,
                        'size' => '-'
                    );
                }
            }
        } catch (Exception $e) {
            return array('error' => $e->getMessage());
        }
        
        return $tables;
    }

    /**
     * 获取表大小（MySQL）
     */
    private static function getTableSize($tableName)
    {
        try {
            $db = Typecho_Db::get();
            $result = $db->fetchRow("
                SELECT ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size 
                FROM information_schema.TABLES 
                WHERE table_name = '{$tableName}'
            ");
            return $result ? $result['size'] . ' MB' : '-';
        } catch (Exception $e) {
            return '-';
        }
    }

    /**
     * 删除表
     */
    public static function dropTable($tableName)
    {
        $db = Typecho_Db::get();
        
        // 安全检查：必须是插件表，不能是核心表
        $prefix = $db->getPrefix();
        $shortName = str_replace($prefix, '', $tableName);
        
        if (in_array($shortName, self::$coreTables)) {
            throw new Exception('不能删除系统核心表');
        }
        
        // 检查表名是否合法（防止SQL注入）
        if (!preg_match('/^' . preg_quote($prefix) . '[a-zA-Z0-9_]+$/', $tableName)) {
            throw new Exception('表名不合法');
        }
        
        $db->query("DROP TABLE IF EXISTS `{$tableName}`");
        return true;
    }

    /**
     * 清空表数据（保留结构）
     */
    public static function truncateTable($tableName)
    {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        $shortName = str_replace($prefix, '', $tableName);
        
        if (in_array($shortName, self::$coreTables)) {
            throw new Exception('不能清空系统核心表');
        }
        
        if (!preg_match('/^' . preg_quote($prefix) . '[a-zA-Z0-9_]+$/', $tableName)) {
            throw new Exception('表名不合法');
        }
        
        $db->query("TRUNCATE TABLE `{$tableName}`");
        return true;
    }
}
